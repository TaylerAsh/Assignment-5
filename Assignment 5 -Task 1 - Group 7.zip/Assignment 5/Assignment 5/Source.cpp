#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main() {
    // Make sure you add the sourcefiles to the "Project Line", it will not read the files in the "Source" File, This is why it wouldn't open    -----------> 
    const string dictionaryFileName = "DictionaryWords.txt.txt"; 
    const string textFileName = "inputtoverify.txt.txt";   

    // Open the dictionary file.
    ifstream dictionaryFile(dictionaryFileName);
    if (!dictionaryFile.is_open()) {
        cout << "Error: Can not open dictionary file: " << dictionaryFileName << endl;
        return 1;
    }

    // Define a vector of strings called words.
    vector<string> dictionaryWords;

    // For each word in the dictionary file, append the word to the words vector.
    string word;
    while (dictionaryFile >> word) {
        dictionaryWords.push_back(word);
    }
    dictionaryFile.close();

    // Open the file to be checked.
    ifstream textFile(textFileName);
    if (!textFile.is_open()) {
        cout << "Error: Could not open text file: " << textFileName << std::endl;
        return 1;
    }

    // For each word in that file.
    while (textFile >> word) 
    {
        if (find(dictionaryWords.begin(), dictionaryWords.end(), word) == dictionaryWords.end()) {
            cout << word << endl;
        }
    }
    textFile.close();

    return 0;
}